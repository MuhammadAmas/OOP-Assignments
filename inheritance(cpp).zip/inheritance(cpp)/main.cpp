#include <iostream>
#include "normalCar.h"
using namespace std;
int main()
{
    normalCar carCharacterstic1;
    normalCar carCharacterstic2;
    normalCar carCharacterstic3;
    normalCar carCharacterstic4;
    normalCar carCharacterstic5;     
    normalCar carCharacterstic6;
    sportsCar carCharacterstic7;
    sportsCar  carCharacterstic8;
    sportsCar  carCharacterstic9;


  //  carCharacterstic1.getAndshow(carCharacterstic1,carCharacterstic2,carCharacterstic3,carCharacterstic4,carCharacterstic5,carCharacterstic6);

   
     carCharacterstic7.showEnhanced(carCharacterstic1,carCharacterstic2,carCharacterstic3,carCharacterstic4,carCharacterstic5,carCharacterstic6, carCharacterstic7,carCharacterstic8,  carCharacterstic9);

}


































